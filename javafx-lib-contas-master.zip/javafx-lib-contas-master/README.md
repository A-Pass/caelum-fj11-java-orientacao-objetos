### javafx-api-lib

Projeto usado no FJ-11.

Para executar:

```bash
$ mvn compile exec:java
```

Para fazer o fat jar para o Java 11 que inclui o JavaFX:

```bash
$ mvn compile package
```

O jar fica no diretório `shade`.